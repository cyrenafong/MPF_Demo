//
//  MPFFundHeaderCell.swift
//  MPFManager
//
//  Created by Sesugh on 14/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit

class MPFFundHeaderCell: UITableViewCell {
    @IBOutlet weak var latestFER: UIButton!
    @IBOutlet weak var fiveYear: UILabel!
    @IBOutlet weak var tenYear: UILabel!


    @IBAction func toggleSort(_ sender: Any) {
        print("Yayyy!")
    }
}
