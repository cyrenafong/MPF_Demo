//
//  UIAlertController+ConstraintExtension.swift
//  MPFManager
//
//  Created by Sesugh on 14/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit

extension UIAlertController {
    func setControllerConstraints(_ child: UIView) {
        let widthConstraints = self.view.constraints.filter({ return $0.firstAttribute == .width })
        self.view.removeConstraints(widthConstraints)
        // Here you can enter any width that you want
        let newWidth = UIScreen.main.bounds.width * 0.90
        // Adding constraint for alert base view
        let widthConstraint = NSLayoutConstraint(item: self.view!,
                                                 attribute: .width,
                                                 relatedBy: .equal,
                                                 toItem: nil,
                                                 attribute: .notAnAttribute,
                                                 multiplier: 1,
                                                 constant: newWidth)
        self.view.addConstraint(widthConstraint)
        let firstContainer = self.view.subviews[0]
        // Finding first child width constraint
        //let constraint = firstContainer.constraints.filter({ return $0.firstAttribute == .width && $0.secondItem == nil })
        //firstContainer.removeConstraints(constraint)

        // And replacing with new constraint equal to alert.view width constraint that we setup earlier
        self.view.addConstraint(NSLayoutConstraint(item: firstContainer,
                                                    attribute: .width,
                                                    relatedBy: .equal,
                                                    toItem: self.view,
                                                    attribute: .width,
                                                    multiplier: 1.0,
                                                    constant: 0))
        // Same for the second child with width constraint with 998 priority
        let innerBackground = firstContainer.subviews[0]
        let innerConstraints = innerBackground.constraints.filter({ return $0.firstAttribute == .width && $0.secondItem == nil })
        innerBackground.removeConstraints(innerConstraints)
        firstContainer.addConstraint(NSLayoutConstraint(item: innerBackground,
                                                        attribute: .width,
                                                        relatedBy: .equal,
                                                        toItem: firstContainer,
                                                        attribute: .width,
                                                        multiplier: 1.0,
                                                        constant: 0))
        
        // Set constraints for Seconds View (Our UIPicker)
        child.removeAllConstraints()

        NSLayoutConstraint.activate([
            child.widthAnchor.constraint(equalTo: self.view.widthAnchor),
            child.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -24),
            child.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 24)
        ])
    }
}
