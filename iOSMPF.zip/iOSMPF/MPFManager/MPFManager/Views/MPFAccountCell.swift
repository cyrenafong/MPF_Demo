//
//  MPFAccountCell.swift
//  MPFManager
//
//  Created by Sesugh on 8/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit

class MPFAccountCell: UITableViewCell {
    @IBOutlet weak var schemeNameLabel: UILabel!
    @IBOutlet weak var accountNoLabel: UILabel!
    @IBOutlet weak var accountValue: UILabel!
    
    func bind(account: MPFAccount) {
        schemeNameLabel.text = account.scheme.name
        accountNoLabel.text = account.accountNumber
        let text = NumberFormatter.standard.string(from: NSNumber(value: account.totalValue))!
        accountValue.text = "HKD \(text)"
    }
}
