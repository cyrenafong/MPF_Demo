//
//  UIView+ConstraintExtension.swift
//  MPFManager
//
//  Created by Sesugh on 12/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit

extension UIView {

    public func removeAllConstraints(_ translatesAutoresizingMaskIntoConstraints: Bool = false) {
        var _superview = self.superview

        while let superview = _superview {
            for constraint in superview.constraints {

                if let first = constraint.firstItem as? UIView, first == self {
                    superview.removeConstraint(constraint)
                }

                if let second = constraint.secondItem as? UIView, second == self {
                    superview.removeConstraint(constraint)
                }
            }

            _superview = superview.superview
        }

        self.removeConstraints(self.constraints)
        self.translatesAutoresizingMaskIntoConstraints = translatesAutoresizingMaskIntoConstraints
    }
    
    public func removeAllWidthConstraints(_ translatesAutoresizingMaskIntoConstraints: Bool = false) {
        var _superview = self.superview

        while let superview = _superview {
            for constraint in superview.constraints {

                if let first = constraint.firstItem as? UIView, first == self && (constraint.firstAttribute == .width || constraint.secondAttribute == .width ) {
                    superview.removeConstraint(constraint)
                }

                if let second = constraint.secondItem as? UIView, second == self && (constraint.firstAttribute == .width || constraint.secondAttribute == .width ) {
                    superview.removeConstraint(constraint)
                }
            }

            _superview = superview.superview
        }

        self.removeConstraints(self.constraints)
        self.translatesAutoresizingMaskIntoConstraints = translatesAutoresizingMaskIntoConstraints
    }
}
