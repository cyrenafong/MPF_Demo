//
//  MPFFundCellTableViewCell.swift
//  MPFManager
//
//  Created by Sesugh on 14/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit

class MPFFundCell: UITableViewCell {
    @IBOutlet weak var fund: UILabel!
    @IBOutlet weak var fer: UILabel!
    @IBOutlet weak var fiveYear: UILabel!
    @IBOutlet weak var tenYear: UILabel!

    func bind(fund: MPFFund) {
        self.fund.text = fund.name
        setText(fer, fund.latestFER.value)
        setText(fiveYear, fund.annualizedReturn5Year.value)
        setText(tenYear, fund.annualizedReturn10Year.value)
    }
    
    private func setText(_ label: UILabel, _ value: Double?) {
        if let value = value {
            label.text = String(format: "%.2f", value) + "%"
        } else {
            label.text = "n/a"
        }
    }
}
