//
//  ViewFundFeesViewController.swift
//  MPFManager
//
//  Created by Sesugh on 14/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit

class ViewFundFeesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var trusteeName: UILabel!
    @IBOutlet weak var schemeName: UILabel!
    @IBOutlet weak var fundClass: UILabel!
    @IBOutlet weak var fundFees: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    var scheme: MPFScheme!
    var fundType: MPFFundType? = nil
    let viewModel = ViewFundFeesViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.fundType = fundType
        viewModel.scheme = scheme
        trusteeName.text = scheme.trustee.fullName
        schemeName.text = scheme.name
        if let fund = fundType  {
            fundClass.text = fund.rawValue
        } else {
            fundClass.text = "All"
        }
        fundClass.backgroundColor = color(for: fundType)
        viewModel.load()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.observeChanges(tableView, fundFees)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        viewModel.invalidate()
    }
    
    func color(for fundType: MPFFundType?) -> UIColor {
        guard let fundType = fundType else {
            return .yellow
        }
        switch fundType {
        case .Equity:
            return .red
        case .MixedAssets:
            return .orange
        case .Bond:
            return .blue
        case .Guaranteed:
            return .green
        case .MoneyMarketConservative:
            return .purple
        case .MoneyMarketNonConservative:
            return .brown
        }
    }
    
    // MARK: - TableView
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.itemCount
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "fundCell") as! MPFFundCell
        let item = viewModel.item(at: indexPath.row)
        cell.bind(fund: item)
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let cell = tableView.dequeueReusableCell(withIdentifier: "fundHeaderCell") as! MPFFundHeaderCell
        let tap = UITapGestureRecognizer(target: self, action: #selector(didSelectHeader))
        setHeaderImage(viewModel.isSortDescending, cell.latestFER)
        cell.latestFER.addGestureRecognizer(tap)
        return cell.contentView
    }
    
    @objc func didSelectHeader(_ gesture: UIGestureRecognizer) {
        if let button = gesture.view! as? UIButton {
            setHeaderImage(!viewModel.isSortDescending, button)
            viewModel.changeSort(tableView, fundFees)
        }
    }
    
    func setHeaderImage(_ isSortDescending: Bool,_ button: UIButton) {
        if !isSortDescending {
                let image = #imageLiteral(resourceName: "chevron-down")
                button.setImage(image.resizeImage(CGFloat(30.0)), for: .normal)
            } else {
                let image = #imageLiteral(resourceName: "chevron-up")
                button.setImage(image.resizeImage(CGFloat(30.0)), for: .normal)
        
            }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 90
    }


}
