//
//  BrowseMPFViewController.swift
//  MPFManager
//
//  Created by Sesugh on 12/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit

class BrowseMPFViewController: BasePickerViewController, UITextFieldDelegate, UIPickerViewDataSource{
    @IBOutlet weak var trusteeTextField: UITextField!
    @IBOutlet weak var schemeTextField: UITextField!
    @IBOutlet weak var btnStack: UIStackView!
    let showFeeFundsSegue = "showFundFees"
    
    var alert: UIAlertController!
    var selectedFundType: MPFFundType? = nil
    let viewModel = BrowseMPFSchemesViewModel()
    
    // MARK: - ViewController
    override func viewDidLoad() {
        super.viewDidLoad()
        updateButtonsState()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == showFeeFundsSegue {
            let dest = segue.destination as! ViewFundFeesViewController
            dest.scheme = viewModel.selectedScheme
            dest.fundType = selectedFundType
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.observeTrusteeChanges {
            self.schemeTextField.text = self.viewModel.selectedScheme.name
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        viewModel.invalidate()
    }
    
    func updateButtonsState() {
        btnStack.isUserInteractionEnabled = viewModel.selectedTrustee != nil && viewModel.selectedScheme != nil
    }
    
    // MARK: - IB Actions
    
    @IBAction func showAll(_ sender: UIView) {
        showFeeFunds(nil)
    }
    
    @IBAction func showEquity(_ sender: UIView) {
        showFeeFunds(.Equity)
    }
    
    @IBAction func showMixed(_ sender: UIView) {
        showFeeFunds(.MixedAssets)
    }
    
    @IBAction func showBond(_ sender: UIView) {
        showFeeFunds(.Bond)
    }
    
    @IBAction func showGuarantee(_ sender: UIView) {
        showFeeFunds(.Guaranteed)
    }
    
    @IBAction func showConservative(_ sender: UIView) {
        showFeeFunds(.MoneyMarketConservative)
    }
    
    @IBAction func showNonConservative(_ sender: UIView) {
        showFeeFunds(.MoneyMarketNonConservative)
    }
    
    func showFeeFunds(_ fundType: MPFFundType?) {
        selectedFundType = fundType
        performSegue(withIdentifier: showFeeFundsSegue, sender: self)
    }
    
    // MARK: - PickerView
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return viewModel.itemCount
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?{
        return viewModel.title(at: row)
    }
    
    // MARK: - TextFieldDelegate
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        viewModel.isTrusteeSelected = textField === trusteeTextField
        if viewModel.isTrusteeSelected || viewModel.selectedTrustee != nil {
            showChoices()
        }
        return false
    }
    
    func showChoices() {
        let title: String
        if viewModel.isTrusteeSelected {
            title = "Choose Trustee"
        } else {
            title = "Choose Scheme"
        }
        
        let pickerFrame: UIPickerView
        if alert == nil {
            alert = UIAlertController(title: title, message: "", preferredStyle: .alert)
            alert.isModalInPopover = true
            
            
            pickerFrame = UIPickerView()
            pickerFrame.tag = 999
            alert.view.addSubview(pickerFrame)
            pickerFrame.dataSource = self
            pickerFrame.delegate = self
            
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                self.handleOKUIAlertAction(pickerFrame)
            }))
            alert.setControllerConstraints(pickerFrame)
        } else {
            alert.title = title
            pickerFrame = alert.view.viewWithTag(999) as! UIPickerView
        }
        viewModel.load()
        viewModel.observeChanges(pickerFrame)
        self.present(alert,animated: true, completion: nil )
    }
    
    func handleOKUIAlertAction(_ pickerView: UIPickerView){
        let row = pickerView.selectedRow(inComponent: 0)
        viewModel.selectItem(at: row)
        if viewModel.isTrusteeSelected {
            trusteeTextField.text = viewModel.title(at: row)
        } else {
            schemeTextField.text = viewModel.title(at: row)
        }
        updateButtonsState()
        alert.dismiss(animated: true, completion: nil)
    }
}
