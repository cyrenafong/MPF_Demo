//
//  ViewController.swift
//  MPFManager
//
//  Created by Kiu Ling Charmian Ho on 27/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit
import PDFKit

class MPFdetailViewController: UIViewController {
     @IBOutlet weak var pdfView1: PDFView!
       
       override func viewDidLoad() {
           super.viewDidLoad()

           if let path = Bundle.main.path(forResource: "YouthBooklet", ofType: "pdf") {
               let url = URL(fileURLWithPath: path)
               if let pdfDocument = PDFDocument(url: url) {
                   pdfView1.displayMode = .singlePageContinuous
                   pdfView1.autoScales = true
                   pdfView1.document = pdfDocument
               }
           }
       }
}
