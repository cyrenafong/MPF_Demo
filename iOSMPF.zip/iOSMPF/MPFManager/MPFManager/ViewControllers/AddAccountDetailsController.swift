//
//  AddAccountDetailsController.swift
//  MPFManager
//
//  Created by Rica on 26/10/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit

class AddAccountDetailsController: UIViewController , UITextFieldDelegate{

    @IBOutlet weak var numberTextField: UITextField!
    @IBOutlet weak var companyTextField: UITextField!
    @IBOutlet weak var balanceTextField: UITextField!
    @IBOutlet weak var btnDone: UIButton!
    var scheme: MPFScheme!
    let segueId = "toAccountSummary"
    
    // MARK: - ViewController
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        textFieldValueChanged(balanceTextField)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        view.endEditing(true)
    }
    
    // MARK: - TextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return false
    }
    
    @IBAction func textFieldValueChanged(_ sender: UITextField){
        btnDone.isEnabled = balanceTextField.text!.count > 0 &&  Double(balanceTextField.text!) != nil && companyTextField.text!.count > 0
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == segueId {
            let value = Double(balanceTextField.text!)!
            let company = companyTextField.text!
            let accountNo = numberTextField.text!
            let account =  MPFAccount(scheme: scheme, totalValue: value, accountNumber: accountNo, employer: company)
            let dest = segue.destination as! AddAccountSummary
            dest.account = account
        }
    }
}
