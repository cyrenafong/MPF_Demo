//
//  HomeViewController.swift
//  MPFManager
//
//  Created by Rica on 15/10/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit
import LocalAuthentication


class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var totalValueLabel: UILabel!
    private let reuseIdentifier = "MPFAccountCell"
    private let viewModel = HomeScreenViewModel()
    
    private let viewAccountOnlineSegue = "viewAccountOnline"
    private let editAccountSegue = "editAccount"
    private var selectedRowForEdit = -1
    
    // MARK: - TableView
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.itemCount
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier) as! MPFAccountCell
        let item = viewModel.item(at: indexPath.item)
        cell.bind(account: item)
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        viewModel.handleEdit(commit: editingStyle, forRowAt: indexPath, self)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: viewAccountOnlineSegue, sender: self)
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let editAction = UIContextualAction(style: .normal, title:  "Edit", handler: { (ac:UIContextualAction, view:UIView, success:(Bool) -> Void) in
            self.selectedRowForEdit = indexPath.row
            self.performSegue(withIdentifier: self.editAccountSegue, sender: self)
            success(true)
        })
        editAction.backgroundColor = .blue
        return UISwipeActionsConfiguration(actions: [editAction])
    }
    
    // MARK: - UIViewController
    override func viewDidLoad() {
        super.viewDidLoad()
        if let check = Passcode.valet.string(forKey: Constants.kPincode) {
            Passcode.present(with: .validate)
        } else {
            Passcode.present(with: .create)
        }
    
        tableView.contentInset.bottom = 100
        viewModel.loadMPFAccounts()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.observeChanges(tableView, totalValueLabel)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.invalidate()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == viewAccountOnlineSegue {
            let dest = segue.destination as! ViewAccoutOnlineViewController
            let row = tableView.indexPathForSelectedRow!.row
            let item = viewModel.item(at: row)
            dest.account = item
        }
        else if segue.identifier == editAccountSegue {
            let dest = segue.destination as! EditAccountViewController
            let item = viewModel.item(at: selectedRowForEdit)
            dest.account = item
        }
    }
    
}

