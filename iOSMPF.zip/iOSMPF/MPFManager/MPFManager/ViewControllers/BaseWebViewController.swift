//
//  BaseWebViewController.swift
//  MPFManager
//
//  Created by Sesugh on 26/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit
import WebKit

class BaseWebViewController: UIViewController, WKNavigationDelegate  {

    let webView = WKWebView()
    var progressView: UIProgressView!
    // A hack to override the default back button behaviour.
    // This is necessary as to avoid not changing the default appearance
    let transparentButton = UIButton()
    
    // MARK: - URL
    // #warning - change this in subclass
    var url = "www.google.com"
    var myContext = 0
    
    deinit {
        webView.removeObserver(self, forKeyPath: "title")
        webView.removeObserver(self, forKeyPath: "estimatedProgress")
        progressView.removeFromSuperview()
    }
    
    // MARK: - ViewController
    
    override func loadView() {
        self.view = webView
        webView.navigationDelegate = self
        progressView = UIProgressView(progressViewStyle: .default)
        progressView.autoresizingMask = [.flexibleWidth, .flexibleTopMargin]
        progressView.tintColor = #colorLiteral(red: 0, green: 0.4784313725, blue: 1, alpha: 1)
        navigationController?.navigationBar.addSubview(progressView)
        let navigationBarBounds = self.navigationController?.navigationBar.bounds
        progressView.frame = CGRect(x: 0, y: navigationBarBounds!.size.height - 2, width: navigationBarBounds!.size.width, height: 2)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initWebView()
        initTransparentButton()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.addSubview(transparentButton)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        transparentButton.removeFromSuperview()
    }
    
    func initWebView() {
        webView.addObserver(self, forKeyPath: "title", options: .new, context: &myContext)
        webView.addObserver(self, forKeyPath: "estimatedProgress", options: .new, context: &myContext)
        
        let url = URL(string: self.url)!
        let request = URLRequest(url: url)
        webView.load(request)
        webView.allowsBackForwardNavigationGestures = true
    }
    
    func initTransparentButton() {
        transparentButton.frame = CGRect(x:0, y:0, width:50, height: 40)
        transparentButton.backgroundColor = UIColor.clear
        transparentButton.addTarget(self, action:#selector(backAction(_:)), for:.touchUpInside)
    }
    
    @objc func backAction(_ sender: UIBarButtonItem) {
        if webView.canGoBack {
            webView.goBack()
        } else {
            navigationController?.popViewController(animated: true)
        }
    }
    
    // MARK: - WebView
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        progressView.isHidden = true
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        progressView.isHidden = false
    }
    
    // MARK: - Observer
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        guard let change = change else { return }
        if context != &myContext {
            super.observeValue(forKeyPath: keyPath, of: object, change: change, context: context)
            return
        }
        if keyPath == "title" {
            if let title = change[NSKeyValueChangeKey.newKey] as? String {
                self.navigationItem.title = title
            }
            return
        }
        if keyPath == "estimatedProgress" {
            if let progress = (change[NSKeyValueChangeKey.newKey] as AnyObject).floatValue {
                progressView.progress = progress;
            }
            return
        }
    }

}
