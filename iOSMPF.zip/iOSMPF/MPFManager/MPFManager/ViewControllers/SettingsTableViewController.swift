//
//  SettingsTableViewController.swift
//  MPFManager
//
//  Created by Sesugh on 8/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit
import MessageUI

class SettingsTableViewController: UITableViewController, MFMailComposeViewControllerDelegate {
    private let viewModel = SettingViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        
    }
    
    // MARK: - Table view data source
    
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                viewModel.clear(self)
            }
        }
        else if indexPath.section == 1 {
            if indexPath.row == 1 {
                performSegue(withIdentifier: "showPrivacyPolicy", sender: self)
            }
            if indexPath.row == 2 {
                showEmailController()
            }
        }
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    
    // MARK: - MFMailComposeViewControllerDelegate
    
    func showEmailController() {
        if MFMailComposeViewController.canSendMail() {
            let composeVC = MFMailComposeViewController()
            
            composeVC.mailComposeDelegate = self
             
            // Configure the fields of the interface.
            composeVC.setToRecipients(["ee4304.group3@gmail.com"])
            composeVC.setSubject("Feedback - MPF Manager")
            composeVC.setMessageBody("Dear Developer,\n", isHTML: false)
             
            // Present the view controller modally.
            self.present(composeVC, animated: true, completion: nil)
        } else {
            let alert = UIAlertController(title: "No Email Account", message: "No email account found on device.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            present(alert, animated: true, completion: nil)
        }
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func Contact(_ sender: Any) {
        showEmailController()
    }
    
    @IBAction func clearData(_ sender: Any) {
        
        viewModel.clear(self)
    }
    
    @IBAction func setPass(_ sender: Any) {
        let menu = UIAlertController(title: "Device Security", message: "Select Action", preferredStyle: .actionSheet)
        let new = UIAlertAction(title: "Create PIN", style: .default, handler: {(alert: UIAlertAction!) -> Void in Passcode.present(with: .create)})
        let update = UIAlertAction(title: "Update PIN", style: .default, handler: {(alert: UIAlertAction!) -> Void in Passcode.present(with: .change)})
        let delete = UIAlertAction(title: "Delete PIN", style: .default, handler: {(alert: UIAlertAction!) -> Void in Passcode.present(with: .deactive)})
        let Cancel = UIAlertAction(title: "Cancel", style: .default, handler: {(alert: UIAlertAction!) -> Void in })
        
        if let check = Passcode.valet.string(forKey: Constants.kPincode) {
            menu.addAction(update)
            menu.addAction(delete)
            menu.addAction(Cancel)
        } else {
            menu.addAction(new)
            menu.addAction(Cancel)
        }
        self.present(menu, animated: true, completion: nil)
    }
    
    /*func pin(_ mode: Mode) {
        Passcode.present(with: mode)
    }*/
    
    
    /* @IBOutlet weak var security: UIButton!
     @IBOutlet weak var sync: UIButton!
     
     @IBAction func securityOption(_ sender: Any) {
     let menu = UIAlertController(title: "Device Security", message: "Select Method", preferredStyle: .actionSheet)
     let M1 = UIAlertAction(title: "PIN", style: .default, handler: {(alert: UIAlertAction!) -> Void in self.security.setTitle("PIN", for: .normal)})
     let M2 = UIAlertAction(title: "Password", style: .default, handler: {(alert: UIAlertAction!) -> Void in self.security.setTitle("Password", for: .normal)})
     let M3 = UIAlertAction(title: "N/A", style: .default, handler: {(alert: UIAlertAction!) -> Void in self.security.setTitle("N/A", for: .normal)})
     let Cancel = UIAlertAction(title: "Cancel", style: .default, handler: {(alert: UIAlertAction!) -> Void in })
     
     menu.addAction(M1)
     menu.addAction(M2)
     menu.addAction(M3)
     menu.addAction(Cancel)
     
     self.present(menu, animated: true, completion: nil)
     }
     
     
     
     @IBAction func pushNotice(_ sender: UISwitch) {
     if sender.isOn {
     print("Notification is On")
     } else {
     print("Notification is Off")
     }
     }
     
     */
    /*
     override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
     
     // Configure the cell...
     
     return cell
     }
     */
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
    
}
