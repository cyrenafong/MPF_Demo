//
//  MPFJourneyViewController.swift
//  MPFManager
//
//  Created by Sesugh on 11/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit
import PDFKit

class MPFJourneyViewController: UIViewController {
    @IBOutlet weak var pdfView: PDFView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let path = Bundle.main.path(forResource: "Five steps to choosing MPF funds", ofType: "pdf") {
            let url = URL(fileURLWithPath: path)
            if let pdfDocument = PDFDocument(url: url) {
                pdfView.displayMode = .singlePageContinuous
                pdfView.autoScales = true
                pdfView.document = pdfDocument
            }
        }
    }

}
