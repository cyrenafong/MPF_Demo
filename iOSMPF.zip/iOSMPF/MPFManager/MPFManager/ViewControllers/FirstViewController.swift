//
//  FirstViewController.swift
//  MPFManager
//
//  Created by Rica on 15/10/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

