//
//  PrivacyPolicyViewController.swift
//  MPFManager
//
//  Created by Sesugh on 26/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit


class PrivacyPolicyViewController: BaseWebViewController {
    override func initWebView() {
        url = "https://www.freeprivacypolicy.com/privacy/view/25c683b7814b60b8302c31d3d4e02388"
        super.initWebView()
    }

}
