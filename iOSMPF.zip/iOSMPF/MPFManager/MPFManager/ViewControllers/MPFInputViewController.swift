//
//  MPFInputViewController.swift
//  MPFManager
//
//  Created by Rica on 15/10/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit

//class MPFInputViewController: UIViewController {
class MPFInputViewController: BasePickerViewController, UIPickerViewDataSource {
    @IBOutlet weak var pickerView: UIPickerView!
    let viewModel = TrusteeViewModel()
    let segueId = "toMPFSchemeList"
    var selectedProvider: MPFTrustee!
    
    // MARK: - PickerView
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        viewModel.itemCount
    }
    
//    @IBOutlet var accountBalance: UITextField!
//    @IBOutlet var trustee: UILabel!
//    @IBOutlet var mpfScheme: UILabel!
//    @IBOutlet var aBLabel: UILabel!
//    @IBOutlet var confirmButton: UIButton!
//    @IBAction func clickedConfirm(_ sender: Any) {
//        // aBLabel.text=accountBalance.text!
//        performSegue(withIdentifier: segueId, sender: self)
//    }
//
//    func numberOfComponents(in pickerView: UIPickerView) -> Int {
//        return 1
//    }
//
//    var trusteeOptions: [String] = []
//    var mpfNameOptions: [String]=[]
//
//    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
//        if pickerView.tag == 0 {
//            return trusteeOptions.count
//        } else {
//            return mpfNameOptions.count
//        }
//    }
//
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?{
//        if pickerView.tag == 0 {
//            return "\(trusteeOptions[row])"
//        } else {
//            return "\(mpfNameOptions[row])"
//        }
        return viewModel.item(at: row).fullName
    }

//    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int){
//        if pickerView.tag == 0 {
//            trustee.text = "\(trusteeOptions[row])"
//        } else {
//            mpfScheme.text = "\(mpfNameOptions[row])"
//        }
//    }

    // MARK: - ViewController
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.load()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.observeChanges(pickerView)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        viewModel.invalidate()
    }

    
    // MARK: - Navigation

 
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == segueId {
            let dest = segue.destination as! AddAccount_Name
            let row = pickerView.selectedRow(inComponent: 0)
            selectedProvider = viewModel.item(at: row)
            dest.trustee = selectedProvider
        }
    }
}
