//
//  RecommendViewController.swift
//  MPFManager
//
//  Created by Viktor Bestle on 19/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit

class RecommendViewController: UIViewController, UITextFieldDelegate {
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
              view.endEditing(true)
          }
    
    @IBOutlet var incomeTextField: UITextField!
    @IBOutlet var yearsSegment: UISegmentedControl!
    @IBOutlet var commentTextView: UITextView!
    @IBOutlet var percentImageView: UIImageView!
   
    
    @IBAction func CaculatePortfolioBtn(_ sender: Any) {
        
        if let income = Float(incomeTextField.text!)  {
        
            let years = yearsSegment.selectedSegmentIndex
            
            let recommendModel = RecommendViewModel(incomePerMonth: income, yearsTillRetire: years)
     
        commentTextView.text = recommendModel.getComment()
        percentImageView.image = UIImage(named: recommendModel.getImageFilename())
        
        
    } else {
    
    // Create the Alert
            let alert = UIAlertController(title: "Data Validation Error", message: "Monthly Income input cannot be empty", preferredStyle: UIAlertController.Style.alert)
    
    // Add an Action (button)
    alert.addAction(UIAlertAction(title: "Close", style: .default, handler: { (action: UIAlertAction!) in print("Data Validation Checking Completed")
        
    }))
    
    // Show the Alert
    present(alert, animated: true, completion: nil)
}
        incomeTextField.resignFirstResponder()
}
    
    
}
