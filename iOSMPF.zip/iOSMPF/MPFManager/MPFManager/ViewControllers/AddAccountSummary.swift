//
//  AddAccountSummary.swift
//  MPFManager
//
//  Created by Rica on 26/10/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit

class AddAccountSummary: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var trusteeField: UITextField!
    @IBOutlet weak var schemeField: UITextField!
    @IBOutlet weak var companyNameField: UITextField!
    @IBOutlet weak var accountNoField: UITextField!
    @IBOutlet weak var balanceField: UITextField!
    
    var account: MPFAccount!
    var viewModel = NewMPFAccountViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        trusteeField.text = account.scheme.trustee.fullName
        schemeField.text = account.scheme.name
        companyNameField.text = account.employer
        balanceField.text = "HKD \(account.totalValue)"
        accountNoField.text = account.accountNumber
    }
    
    @IBAction func clickConfirmed(_ sender: UIButton){
        viewModel.addMPFAccount(account)
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    // MARK: - TextField
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return false
    }
}
