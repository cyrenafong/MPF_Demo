//
//  BasePickerViewController.swift
//  MPFManager
//
//  Created by Sesugh on 23/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit

class BasePickerViewController: UIViewController, UIPickerViewDelegate {
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        
        let delegate = self as UIPickerViewDelegate
        let text: String = delegate.pickerView?(pickerView, titleForRow: row, forComponent: component) ?? ""
        
        let label: UILabel
        if let view = view {
            label = view as! UILabel
        }
        else {
            label = UILabel(frame: CGRect(x: 0, y: 0, width: pickerView.frame.width, height: 400))
        }
        label.lineBreakMode = .byWordWrapping;
        label.numberOfLines = 0;
        label.text = text
        label.sizeToFit()
        return label;
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 60.0
    }
}
