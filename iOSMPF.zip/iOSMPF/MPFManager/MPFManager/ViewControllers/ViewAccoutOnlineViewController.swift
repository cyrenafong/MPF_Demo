//
//  ViewAccoutOnlineViewController.swift
//  MPFManager
//
//  Created by Sesugh on 8/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit
import WebKit

class ViewAccoutOnlineViewController: BaseWebViewController {
   
    var account: MPFAccount!
    override func initWebView() {
        url = account.scheme.loginLink!
        super.initWebView()
    }
}
