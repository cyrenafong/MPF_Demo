//
//  FAQViewController.swift
//  MPFManager
//
//  Created by Kiu Ling Charmian Ho on 27/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit
import PDFKit
class FAQViewController: UIViewController {

    

    @IBOutlet weak var FAQView: PDFView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let path = Bundle.main.path(forResource: "FAQ", ofType: "pdf") {
            let url = URL(fileURLWithPath: path)
            if let pdfDocument = PDFDocument(url: url) {
                FAQView.displayMode = .singlePageContinuous
                FAQView.autoScales = true
                FAQView.document = pdfDocument
            }
        }
    }
    
    
    
  

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
