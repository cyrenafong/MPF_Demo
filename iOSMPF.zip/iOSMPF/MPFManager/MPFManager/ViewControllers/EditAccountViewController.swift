//
//  EditAccountViewController.swift
//  MPFManager
//
//  Created by Sesugh on 8/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit

class EditAccountViewController: BasePickerViewController, UITextFieldDelegate, UIPickerViewDataSource {
    
    
    @IBOutlet weak var trusteeTextField: UITextField!
    @IBOutlet weak var schemeTextField: UITextField!
    @IBOutlet weak var companyTextField: UITextField!
    @IBOutlet weak var accountTextField: UITextField!
    @IBOutlet weak var balanceTextField: UITextField!
    @IBOutlet weak var saveButton: UIBarButtonItem!
    
    var alert: UIAlertController!
    
    var account: MPFAccount!
    var viewModel = EditAccountViewModel()
    
    
    // MARK: - ViewController
    override func viewDidLoad() {
        super.viewDidLoad()
        trusteeTextField.text = account.scheme.trustee.fullName!
        schemeTextField.text = account.scheme.name!
        companyTextField.text = account.employer
        accountTextField.text = account.accountNumber
        balanceTextField.text = "\(account.totalValue)"
        viewModel.initialize(account)
        textFieldValueChanged(balanceTextField)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.observeTrusteeChanges(onTrusteeChanged)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        viewModel.invalidate()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        view.endEditing(true)
    }
    
    @IBAction func saveChanges(_ sender: UIBarButtonItem) {
        viewModel.update {
            self.account.totalValue = Double(self.balanceTextField.text!)!
            self.account.scheme = self.viewModel.selectedScheme!
            self.account.employer = self.companyTextField.text!
        }
        let alert = UIAlertController(title: "Changes saved", message: "", preferredStyle: .alert)
        alert.isModalInPopover = true
        alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    // MARK: - TextFieldDelegate
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        let showPicker =  textField === trusteeTextField || textField === schemeTextField
        if showPicker {
            viewModel.isTrusteeSelected = textField === trusteeTextField
            showChoices()
        }
        let disabled = showPicker || textField === accountTextField
        return !disabled
    }
    
    @IBAction func textFieldValueChanged(_ sender: UITextField){
        saveButton.isEnabled = balanceTextField.text!.count > 0 &&  Double(balanceTextField.text!) != nil && companyTextField.text!.count > 0
    }
    
    func showChoices() {
        let title: String
        if viewModel.isTrusteeSelected {
            title = "Choose Trustee"
        } else {
            title = "Choose Scheme"
        }
        
        let pickerFrame: UIPickerView
        if alert == nil {
            alert = UIAlertController(title: title, message: "", preferredStyle: .alert) //\n\n\n\n\n\n
            alert.isModalInPopover = true
            
            
            pickerFrame = UIPickerView() // 250 X 140 //frame: CGRect(x: 5, y: 20, width: 300, height: 140)
            pickerFrame.tag = 999
            alert.view.addSubview(pickerFrame)
            pickerFrame.dataSource = self
            pickerFrame.delegate = self
            
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                self.handleOKUIAlertAction(pickerFrame)
            }))
            alert.setControllerConstraints(pickerFrame)
        } else {
            pickerFrame = alert.view.viewWithTag(999) as! UIPickerView
        }
        viewModel.load()
        viewModel.observeChanges(pickerFrame)
        self.present(alert,animated: true, completion: nil )
    }
    
    // MARK: - PickerView
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return viewModel.itemCount
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?{
        return viewModel.title(at: row)
    }
    
    func handleOKUIAlertAction(_ pickerView: UIPickerView){
        let row = pickerView.selectedRow(inComponent: 0)
        viewModel.selectItem(at: row)
        if viewModel.isTrusteeSelected {
            trusteeTextField.text = viewModel.title(at: row)
        } else {
            schemeTextField.text = viewModel.title(at: row)
        }
        alert.dismiss(animated: true, completion: nil)
    }
    
    
    
    
    // MARK: - ViewModel Interations
    func onTrusteeChanged(){
        schemeTextField.text = viewModel.selectedScheme.name!
    }
    
    func displayViews(_ view: UIView, _ indent: Int = 0) {
        print("\(String(repeating: "\t", count: indent))\(type(of: view)) \(view.tag) \(labelText(view))")
        for v in view.subviews {
            displayViews(v, indent + 1)
        }
    }
    
    func labelText(_ view: UIView) -> String{
        if view is UILabel {
            return (view as! UILabel).text ?? ""
        }
        return ""
    }
}
