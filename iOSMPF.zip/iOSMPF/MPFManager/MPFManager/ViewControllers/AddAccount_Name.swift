//
//  AddAccount_Name.swift
//  MPFManager
//
//  Created by Rica on 26/10/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit

class AddAccount_Name: BasePickerViewController, UIPickerViewDataSource {
    @IBOutlet weak var pickerView: UIPickerView!
    let viewModel = SchemesViewModel()
    let segueId = "toEnterAccountBalanceScreen"
    var trustee: MPFTrustee!
    var selectedScheme: MPFScheme!

    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.load(trustee)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.observeChanges(pickerView)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        viewModel.invalidate()
    }
    
    // MARK: - PickerView
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        viewModel.itemCount
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let item = viewModel.item(at: row)
        return item.name
    }

  

    
    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == segueId {
            let dest = segue.destination as! AddAccountDetailsController
            let row = pickerView.selectedRow(inComponent: 0)
            selectedScheme = viewModel.item(at: row)
            dest.scheme = selectedScheme
        }
    }
    

}
