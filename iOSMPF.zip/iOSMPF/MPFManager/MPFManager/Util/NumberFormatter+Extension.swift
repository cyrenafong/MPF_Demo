//
//  Util.swift
//  MPFManager
//
//  Created by Sesugh on 23/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import Foundation

extension NumberFormatter {
    static let standard: NumberFormatter = {
        var formatter = NumberFormatter()
        formatter.usesGroupingSeparator = true
        formatter.locale = Locale.current
        formatter.numberStyle = .decimal
        return formatter
    }()
}
