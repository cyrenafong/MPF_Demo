//
//  RecommendViewModel.swift
//  MPFManager
//
//  Created by Viktor Bestle on 20/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import Foundation

class RecommendViewModel {
    
    var income: Float
    var years: Int
    
    init(incomePerMonth: Float, yearsTillRetire: Int) {
        years = yearsTillRetire
        income = incomePerMonth
    }
    

    
    func getComment() -> String {
        
        if (years == 0) {
            
            if (income > 30000) {
            return "Due to your long period of working years before retiring and your level of income, we recommend you choose a risk profile categorized as “very high”. This meaning a distribution of your savings being invested 90% in stocks and the remaining 10% in bonds."
                
        } else if (income == 30000 || 30000 > income && income > 15000) {
            return "Due to your long period of working years before retiring and your level of income, we recommend you choose a risk profile categorized as “high”. This meaning a distribution of your savings being invested 70% in stocks and the remaining 30% in bonds."
                
        } else if (income == 15000 || 15000 > income) {
            return "Due to your long period of working years before retiring and your level of income, we recommend you choose a risk profile categorized as “medium”. This meaning a distribution of your savings being invested 50% in stocks and the remaining 50% in bonds."
        }
            
            
    } else if (years == 1) {
            
        if (income > 30000){
        return "Due to your fair amount of working years before retiring and your level of income, we recommend you choose a risk profile categorized as “high”. This meaning a distribution of your savings being invested 70% in stocks and the remaining 30% in bonds."
            
    } else if (income == 30000 || 30000 > income && income > 15000) {
        return "Due to your fair amount of working years before retiring and your level of income, we recommend you choose a risk profile categorized as “medium”. This meaning a distribution of your savings being invested 50% in stocks and the remaining 50% in bonds."
            
    } else if (income == 15000 || 15000 > income) {
        return "Due to your fair amount of working years before retiring and your level of income, we recommend you choose a risk profile categorized as “low”. This meaning a distribution of your savings being invested 30% in stocks and the remaining 70% in bonds."
    }
            
            
    } else if (years == 2) {
            
        if (income > 30000){
        return "Due to your relatively short period of working years before retiring and your level of income, we recommend you choose a risk profile categorized as “medium”. This meaning a distribution of your savings being invested 50% in stocks and the remaining 50% in bonds."
            
    } else if (income == 30000 || 30000 > income && income > 15000) {
        return "Due to your relatively short period of working years before retiring and your level of income, we recommend you choose a risk profile categorized as “low”. This meaning a distribution of your savings being invested 30% in stocks and the remaining 70% in bonds."
            
    } else if (income == 15000 || 15000 > income) {
        return "Due to your relatively short period of working years before retiring and your level of income, we recommend you choose a risk profile categorized as “very low”. This meaning a distribution of your savings being invested 10% in stocks and the remaining 90% in bonds."
    }
        }
        return "Unvalid"
    }
    
    
    
    
    func getImageFilename() -> String {
             
            if (years == 0) {
                
                if (income > 30000){
                return "1090_portfolio.png"
                    
            } else if (income == 30000 || 30000 > income && income > 15000) {
                return "3070_portfolio.png"
                    
            } else if (income == 15000 || 15000 > income) {
                return "5050_portfolio.png"
            }
                
                
        } else if (years == 1) {
                
            if (income > 30000){
            return "3070_portfolio.png"
                
        } else if (income == 30000 || 30000 > income && income > 15000) {
            return "5050_portfolio.png"
                
        } else if (income == 15000 || 15000 > income) {
            return "7030_portfolio.png"
        }
                
                
        } else if (years == 2) {
                
            if (income > 30000){
            return "5050_portfolio.png"
                
        } else if (income == 30000 || 30000 > income && income > 15000) {
            return "7030_portfolio.png"
                
        } else if (income == 15000 || 15000 > income) {
            return "9010_portfolio.png"
        }
            }
        return "Unvalid"
    }
    
}
