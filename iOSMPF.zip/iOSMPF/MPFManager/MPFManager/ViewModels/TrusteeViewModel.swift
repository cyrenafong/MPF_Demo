//
//  TrusteeViewModel.swift
//  MPFManager
//
//  Created by Sesugh on 6/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import RealmSwift
import UIKit

class TrusteeViewModel: BaseViewModel {
    private var items: Results<MPFTrustee>? =  nil
    private var itemsToken: NotificationToken? =  nil

    var itemCount: Int {
        if let providers = self.items {
            return providers.count
        }
        return 0
    }
    
    func load() {
        items = database.realm.objects(MPFTrustee.self)
    }
    
    func observeChanges(_ pickerView: UIPickerView) {
        itemsToken = items?.observe { [weak pickerView] changes in
            guard let pickerView = pickerView else {
                return
            }
            pickerView.reloadAllComponents()
        }
    }
    
    func item(at position: Int) -> MPFTrustee {
        return items![position]
    }
    
    func invalidate() {
        itemsToken?.invalidate()
    }
}
