//
//  ViewFundFeesViewModel.swift
//  MPFManager
//
//  Created by Sesugh on 14/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import Foundation
import RealmSwift
import UIKit

class ViewFundFeesViewModel: BaseViewModel {
    var scheme: MPFScheme!
    var fundType: MPFFundType? = nil
    private var items: Results<MPFFund>? = nil
    private var itemsToken: NotificationToken? = nil
    var isSortDescending = true
    
    var itemCount: Int {
        if let items = self.items {
            return items.count
        }
        return 0
    }
    
    
    func load() {
        if let fundType = self.fundType {
            items = database.realm.objects(MPFFund.self).filter("scheme.name = %@ AND type BEGINSWITH %@", scheme.name!, fundType.rawValue).sorted(byKeyPath: "latestFER", ascending: isSortDescending)
        } else {
            items = database.realm.objects(MPFFund.self).filter("scheme.name = %@", scheme.name!).sorted(byKeyPath: "latestFER", ascending: isSortDescending)
        }
    }
    
    func changeSort(_ tableView: UITableView, _ fundCount: UILabel) {
        if let items = items {
            isSortDescending = !isSortDescending
            self.items = items.sorted(byKeyPath: "latestFER", ascending: isSortDescending)
            observeChanges(tableView, fundCount)
        }
    }
    
    
    func observeChanges(_ tableView: UITableView, _ fundCount: UILabel) {
        itemsToken = items?.observe { [weak tableView, weak fundCount] changes in
            guard let tableView = tableView else {
                return
            }
            guard let fundCount = fundCount else {
                return
            }
            switch changes {
            case .initial:
                tableView.reloadData()
            case .error(let error):
                // handle error
                print(error.localizedDescription)
            case .update(_, _,  _,  _): break
                
            }
            let text: String
            if self.items!.count != 1 {
                text = "Funds"
            } else {
                text = "Fund"
            }
            fundCount.text = "\(self.items!.count) \(text)"
        }
    }
    
    func item(at position: Int) -> MPFFund {
        return items![position]
    }
    
    func invalidate() {
        itemsToken?.invalidate()
    }
}
