//
//  NewMPFAccountViewModel.swift
//  MPFManager
//
//  Created by Sesugh on 6/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import Foundation

class NewMPFAccountViewModel: BaseViewModel {
    func addMPFAccount(_ account: MPFAccount) {
        database.save(account)
    }
}
