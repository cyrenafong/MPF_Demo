//
//  SchemesViewModel.swift
//  MPFManager
//
//  Created by Sesugh on 27/10/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import UIKit
import RealmSwift

class SchemesViewModel: BaseViewModel {
    private var items: Results<MPFScheme>? = nil
    private var itemsToken: NotificationToken? = nil
    private var trustee: MPFTrustee!
    
    var itemCount: Int {
        if let items = self.items {
            return items.count
        }
        return 0
    }
    

    func load(_ trustee: MPFTrustee) {
        self.trustee = trustee
        items = database.realm.objects(MPFScheme.self).filter("trustee.fullName = %@", self.trustee.fullName!)
    }
    
    func observeChanges(_ pickerView: UIPickerView) {
        itemsToken = items?.observe { [weak pickerView] changes in
            guard let pickerView = pickerView else {
                return
            }
            pickerView.reloadAllComponents()
        }
    }
    
    func add(_ account: MPFAccount){
        // db?.save(object: account) 
    }
    
    func item(at position: Int) -> MPFScheme {
        return items![position]
    }
    
    func invalidate() {
        itemsToken?.invalidate()
    }
}
