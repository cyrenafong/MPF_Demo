//
//  BrowseMPFSchemesViewModel.swift
//  MPFManager
//
//  Created by Sesugh on 11/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import Foundation
import RealmSwift
import UIKit

class BrowseMPFSchemesViewModel : BaseViewModel {
    private var trustees: Results<MPFTrustee>? = nil
    private var schemes: Results<MPFScheme>? = nil
    private var trusteeItemsToken: NotificationToken? = nil
    private var schemeItemsToken: NotificationToken? = nil
    
    var isTrusteeSelected: Bool = true
    var selectedTrustee: MPFTrustee! = nil
    var selectedScheme: MPFScheme! = nil
    var onTrusteeChanged: (() -> Void)? = nil
    
    var itemCount: Int {
        if isTrusteeSelected {
            return trusteeCount
        }
        return schemeCount
    }
    
    var selectedSchemeRow: Int {
        var row = -1
        if let schemes = self.schemes, let selectedScheme = self.selectedScheme {
            for s in schemes {
                row += 1
                if s.name == selectedScheme.name {
                    return row
                }
            }
        }
        return row
    }
    
    var selectedTrusteeRow: Int {
        var row = -1
        if let trustees = self.trustees, let selectedTrustee = self.selectedTrustee {
            for t in trustees {
                row += 1
                if t.shortName! == selectedTrustee.shortName {
                    return row
                }
            }
        }
        return row
    }
    
    private var trusteeCount: Int {
        if let items = self.trustees {
            return items.count
        }
        return 0
    }
    
    private var schemeCount: Int {
        if let items = self.schemes {
            return items.count
        }
        return 0
    }
    
    func load() {
        if isTrusteeSelected {
            loadTrustees()
        } else {
            loadSchemes()
        }
    }
    
    func observeTrusteeChanges(_  callback: @escaping()-> Void) {
        onTrusteeChanged = callback
    }

    private func loadSchemes() {
        schemes = database.realm.objects(MPFScheme.self).filter("trustee.fullName = %@", selectedTrustee.fullName!)
    }
    
    private func loadTrustees() {
        trustees = database.realm.objects(MPFTrustee.self)
    }
    
    func observeChanges(_ pickerView: UIPickerView) {
        if isTrusteeSelected {
            observeTrusteeChanges(pickerView)
        } else {
            observeSchemeChanges(pickerView)
        }
    }
    
    private func observeSchemeChanges(_ pickerView: UIPickerView) {
        schemeItemsToken = schemes?.observe { [weak pickerView] changes in
            guard let pickerView = pickerView else {
                return
            }
            pickerView.reloadAllComponents()
            pickerView.selectRow(self.selectedSchemeRow, inComponent: 0, animated: false)
        }
    }
    
    private func observeTrusteeChanges(_ pickerView: UIPickerView) {
        trusteeItemsToken = trustees?.observe { [weak pickerView] changes in
            guard let pickerView = pickerView else {
                return
            }
            pickerView.reloadAllComponents()
            pickerView.selectRow(self.selectedTrusteeRow, inComponent: 0, animated: false)
        }
    }
    
    
    private func scheme(at position: Int) -> MPFScheme {
        return schemes![position]
    }
    
    private func trustee(at position: Int) -> MPFTrustee {
        return trustees![position]
    }
    
    func invalidate() {
        trusteeItemsToken?.invalidate()
        schemeItemsToken?.invalidate()
    }
    
    func selectItem(at position: Int) {
        if isTrusteeSelected {
            let newTrustee = trustee(at: position)
            if selectedTrustee == nil || newTrustee.shortName != selectedTrustee!.shortName {
                selectedTrustee = newTrustee
                
                // Fetch first scheme
                loadSchemes()
                selectedScheme = schemes!.first
                onTrusteeChanged?()
            }
        } else {
            selectedScheme = scheme(at: position)
        }
    }
    
    func title(at position: Int) -> String {
        if isTrusteeSelected {
            return trustee(at: position).fullName!
        }
        return scheme(at: position).name!
    }
}
