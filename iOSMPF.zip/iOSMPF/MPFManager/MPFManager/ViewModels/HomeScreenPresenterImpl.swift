//
//  HomeScreenPresenterImpl.swift
//  MPFManager
//
//  Created by Sesugh on 27/10/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import Foundation
import UIKit

class HomeScreenViewModel: HomeScreenPresenter {
    var accounts: [MPFAccount] = []
    
    func loadMPFAccounts(callback: ([MPFAccount]) -> Unit) {
            
    }
    
    func addMPFAccount(controller: UIViewController) {
        
    }
    
    func viewMPFAccount(controller: UIViewController) {
        
    }
    
    
}
