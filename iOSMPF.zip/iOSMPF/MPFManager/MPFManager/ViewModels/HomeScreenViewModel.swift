//
//  HomeScreeViewModel.swift
//  MPFManager
//
//  Created by Sesugh on 27/10/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import RealmSwift
import UIKit


class HomeScreenViewModel: BaseViewModel {
    private var accounts: Results<MPFAccount>? =  nil
    private var itemsToken: NotificationToken? =  nil
    var itemCount:  Int {
        if let accounts = self.accounts {
            return accounts.count
        }
        return 0
    }
    
    func loadMPFAccounts() {
        accounts = database.realm.objects(MPFAccount.self)
    }
    
    func observeChanges(_ tableView: UITableView, _ totalValueLabel: UILabel) {
        itemsToken = accounts?.observe { [weak tableView, weak totalValueLabel] changes in
            guard let tableView = tableView else {
                return
            }
            guard let totalValueLabel = totalValueLabel else {
                return
            }
            switch changes {
            case .initial:
                tableView.reloadData()
            case .update(_, let deletions, let insertions, let updates):
                tableView.applyChanges(deletions: deletions, insertions: insertions, updates: updates)
            case .error(let error):
                // handle error
                print(error.localizedDescription)
            }
            var sum: Double = 0
            for item in self.accounts! {
                sum += item.totalValue
            }
            
            totalValueLabel.text = "HKD \(NumberFormatter.standard.string(from: NSNumber(value: sum))!)"
        }
    }
    
    func item(at position: Int) -> MPFAccount {
        return accounts![position]
    }
    
    func handleEdit(commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath, _ controller: UIViewController){
        if editingStyle == .delete {
            let item = self.item(at: indexPath.row)
            
            let alertController = UIAlertController(title: "Delete Account", message: "Are you sure you want to delete \"\(item.scheme!.name!)\"?", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default) { _ in self.removeMPFAccount(item) }
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { _ in}
            alertController.addAction(okAction)
            alertController.addAction(cancelAction)
            
            
            controller.present(alertController, animated: true, completion: nil)
        }
    }
    
    func removeMPFAccount(_ account: MPFAccount) {
        database.delete(account)
    }
    
    func viewMPFAccount(controller: UIViewController) {
        
    }
    
    func invalidate() {
        itemsToken?.invalidate()
    }
    
}
