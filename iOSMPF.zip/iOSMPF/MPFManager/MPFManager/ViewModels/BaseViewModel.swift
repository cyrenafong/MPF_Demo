//
//  BaseViewModel.swift
//  MPFManager
//
//  Created by Sesugh on 6/11/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import Foundation
import UIKit
import RealmSwift

class BaseViewModel {
    

    var database: Database {
          return (UIApplication.shared.delegate as! AppDelegate).database
    }
    
    func runOnUI(_ block : @escaping () -> Void) {
        DispatchQueue.main.async {
            block()
        }
    }
   
}
