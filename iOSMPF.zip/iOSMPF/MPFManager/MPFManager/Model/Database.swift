//
//  Database.swift
//  MPFManager
//
//  Created by Sesugh on 27/10/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import Foundation
import RealmSwift

class Database {
    var realm: Realm!
    
    init() {
        initializeRealm()
        initializeRealmMigration()
        realm = try! Realm()
    }
    
    private func initializeRealm() {
        let defaultRealmPath = Realm.Configuration.defaultConfiguration.fileURL!
        let path = Bundle.main.path(forResource: "mpf.realm", ofType: nil)!
        let bundleRealmPath = URL(fileURLWithPath: path)
        if !FileManager.default.fileExists(atPath: defaultRealmPath.path) {
            do {
                try FileManager.default.copyItem(at: bundleRealmPath, to: defaultRealmPath)
            } catch let error {
                print("error copying seeds: \(error)")
            }
        }
    }
    
    private func initializeRealmMigration() {
        let config = Realm.Configuration(
            schemaVersion: 1,
            migrationBlock: { migration, oldSchemaVersion in }
        )
        Realm.Configuration.defaultConfiguration = config
    }
    
    func save(_ obj: Object, errorHandler: @escaping ((_ error : Error) -> Void) = { fatalError($0.localizedDescription) }) {
        do {
            try realm.write {
                realm.add(obj)
            }
        }
        catch let error {
            errorHandler(error)
        }
    }
    
    func write(_ block: @escaping ()->Void, errorHandler: @escaping ((_ error : Error) -> Void) = { fatalError($0.localizedDescription) }) {
        do {
            try realm.write {
                block()
            }
        }
        catch let error {
            errorHandler(error)
        }
    }
    
    func delete(_ obj: Object, errorHandler: @escaping ((_ error : Error) -> Void) = { fatalError($0.localizedDescription) }) {
        do {
            try realm.write {
                realm.delete(obj)
            }
        }
        catch let error {
            errorHandler(error)
        }
    }
    
    func writeAsync<T : ThreadConfined>(obj: T, errorHandler: @escaping ((_ error : Error) -> Void) = { _ in return }, block: @escaping ((Realm, T) -> Void)) {
        let wrappedObj = ThreadSafeReference(to: obj)
        DispatchQueue(label: "background").async {
            autoreleasepool {
                do {
                    let realm = try Realm()
                    guard let obj = realm.resolve(wrappedObj) else {
                        return // obj was deleted
                    }
                    try realm.write {
                        block(realm, obj)
                    }
                }
                catch let error {
                    errorHandler(error)
                }
            }
        }
    }
    
    func readAsync<T : Object>(errorHandler: @escaping ((_ error : Swift.Error) -> Void) = { _ in return }, _ block: @escaping ((Results<T>) -> Void)) {
        DispatchQueue(label: "background").async {
            autoreleasepool {
                do {
                    let realm = try Realm()
                    block(realm.objects(T.self))
                }
                catch {
                    errorHandler(error)
                }
            }
        }
    }

}
