//
//  Models.swift
//  MPFManager
//
//  Created by Sesugh on 27/10/2019.
//  Copyright © 2019 EE4304. All rights reserved.
//

import Foundation
import RealmSwift


class MPFAccount: Object {
    @objc dynamic var accountNumber: String = NSUUID().uuidString
    @objc dynamic var scheme: MPFScheme!
    @objc dynamic var employer: String = ""
    @objc dynamic var totalContribution: Double = 0
    @objc dynamic var totalValue: Double  = 0
    let assets = List<MPFAsset>()
    
    convenience init(scheme: MPFScheme, totalValue: Double, accountNumber: String = "", employer: String = "") {
        self.init()
        self.accountNumber = accountNumber
        self.scheme = scheme
        self.totalValue = totalValue
        self.employer = employer
    }
    
    override class func primaryKey() -> String? {
        "accountNumber"
    }
}

class MPFScheme: Object {
    @objc dynamic var name: String! = ""
    @objc dynamic var loginLink: String! = ""
    @objc dynamic var trustee: MPFTrustee!
}

class MPFFund: Object {
    @objc dynamic var scheme: MPFScheme?
    @objc dynamic var name: String? = nil
    @objc dynamic var type: String? = nil
    @objc dynamic var launchDate: String? = nil
    let size = RealmOptional<Double>()
    let latestFER = RealmOptional<Double>()
    let riskIndicator = RealmOptional<Double>()
    let annualizedReturn1Year = RealmOptional<Double>()
    let annualizedReturn5Year = RealmOptional<Double>()
    let annualizedReturn10Year = RealmOptional<Double>()
    let annualizedSinceLaunch = RealmOptional<Double>()
    let cumulativeReturn1Year = RealmOptional<Double>()
    let cumulativeReturn5Year = RealmOptional<Double>()
    let cumulativeReturn10Year = RealmOptional<Double>()
    let cumulativeSinceLaunch = RealmOptional<Double>()
    @objc dynamic var managementFee: Double = 0
    @objc dynamic var adminFee: Double = 0
    @objc dynamic var sponsorFee: Double = 0
    @objc dynamic var investmentManagementFee: Double = 0
    @objc dynamic var guaranteeCharge: Double = 0
}

class MPFTrustee: Object {
    @objc dynamic var fullName: String? = nil
    @objc dynamic var shortName: String? = nil
}

class MPFAsset: Object {
    @objc dynamic var value: Double = 0.0
    @objc dynamic var unitValue: Double = 0.0
    @objc dynamic var units: Double = 0.0
    @objc dynamic var contribution: Double = 0.0
    @objc dynamic var fund: MPFFund!
}

enum MPFFundType: String {
    case Equity = "Equity Fund"
    case MixedAssets = "Mixed Assets Fund"
    case Bond = "Bond Fund"
    case Guaranteed = "Guaranteed Fund"
    case MoneyMarketConservative = "Money Market Fund - MPF Conservative Fund"
    case MoneyMarketNonConservative = "Money Market Fund - Other than MPF Conservative Fund"
}
